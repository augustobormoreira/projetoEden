package Main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Augusto
 */
public class Aluno {
    private String nome, idade, sobrenome, turma, rga, cpf, sexo;
    
    public Aluno(String nome, String idade, String sobrenome, String turma, String rga, String cpf, String sexo){
        this.nome = nome;
        this.idade = idade;
        this.sobrenome = sobrenome;
        this.turma = turma;
        this.rga = rga;
        this.cpf = cpf;
        this.sexo = sexo;
    }
    
    public void setAll(String nome, String idade, String sobrenome, String turma, String rga, String cpf, String sexo){
        setNome(nome);
        setIdade(idade);
        setSobrenome(sobrenome);
        setTurma(turma);
        setRga(rga);
        setCpf(cpf);
        setSexo(sexo);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getTurma() {
        return turma;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }

    public String getRga() {
        return rga;
    }

    public void setRga(String rga) {
        this.rga = rga;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    
    
    
}
